Use with:

No Intro
Phantasy Star 0 (Europe).nds
CRC32:              B9027C0C
MD5:                7B13926D3B02A730588537E0577A2DBD
RA Checksum:		113c2fd7665b28122be821b1809230ac